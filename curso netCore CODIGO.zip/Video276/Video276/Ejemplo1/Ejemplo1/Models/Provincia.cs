﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Ejemplo1.Models
{
    public enum Provincia
    {
        Ninguna, Albacete, Alicante, Almería, Álava, Asturias, Ávila, Badajoz, Baleares, Barcelona, Bizkaia,
        Burgos, Cáceres, Cádiz, Cantabria, Castellón, CiudadReal, Córdoba, Coruña, Cuenca, Guipuzcoa,
        Girona, Granada, Guadalajara, Huelva, Huesca, Jaén, León, Lleida, Lugo, Madrid, Málaga, Murcia,
        Navarra, Ourense, Palencia, Palmas, Pontevedra, Rioja, Salamanca, Tenerife, Segovia, Sevilla,
        Soria, Tarragona, Teruel, Toledo, Valencia, Valladolid, Zamora, Zaragoza, Ceuta, Melilla

    }
}
