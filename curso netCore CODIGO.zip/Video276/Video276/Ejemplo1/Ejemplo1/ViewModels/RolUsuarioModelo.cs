﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Ejemplo1.ViewModels
{
    public class RolUsuarioModelo
    {
        public string RolId { get; set; }
        public string RolNombre { get; set; }
        public bool EstaSeleccionado { get; set; }
    }
}
