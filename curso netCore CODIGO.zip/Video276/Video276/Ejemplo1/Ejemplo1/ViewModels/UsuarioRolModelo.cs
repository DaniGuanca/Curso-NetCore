﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Ejemplo1.ViewModels
{
    public class UsuarioRolModelo
    {
        public string UsuarioId { get; set; }
        public string UsuarioNombre { get; set; }
        public bool EstaSeleccionado { get; set; }
    }
}
