﻿using Ejemplo1.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Ejemplo1.ViewModels
{
    public class DetallesView
    {
        public string Titulo { get; set; }

        public string SubTitulo { get; set; }
        public Amigo amigo { get; set; }
    }
}
