﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Ejemplo1.ViewModels
{
    public class UsuarioClaim
    {
        public string tipoClaim { get; set; }
        public bool estaSeleccioando { get; set; }
    }
}
