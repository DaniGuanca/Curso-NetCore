﻿using System;

namespace Ejemplo1AccesoDatos
{
    public class Class1
    {
    }
}
