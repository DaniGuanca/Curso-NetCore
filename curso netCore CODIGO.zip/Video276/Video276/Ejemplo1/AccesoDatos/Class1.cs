﻿using System;

namespace AccesoDatos
{
    public class Class1
    {
    }
}
