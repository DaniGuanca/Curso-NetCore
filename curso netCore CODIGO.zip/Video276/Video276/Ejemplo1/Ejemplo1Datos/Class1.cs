﻿using System;

namespace Ejemplo1Datos
{
    public class Class1
    {
    }
}
